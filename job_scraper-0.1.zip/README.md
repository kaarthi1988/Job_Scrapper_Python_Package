# Job Scraper Package

## Overview

This package provides functionality to scrape job postings from Indeed based on user-defined search keywords and the number of pages to scrape. The results are saved in a CSV file.

## Requirements

Before you begin, ensure you have the following installed:

- Python 3.x
- Pip
- Required libraries:
  - pandas
  - requests
  - beautifulsoup4
  - hrequests
  - numpy
  - tkinter

## Installation

### 1. Download the Package

Download the package from the repository. The package should be in `.tar.gz` or `.zip` format.

### 2. Unzip the File

- **For `.zip` files**: Right-click the zip file and select "Extract All" or use a tool like 7-Zip or WinRAR.
- **For `.tar.gz` files**: Use a tool like 7-Zip or WinRAR to extract it, or use command line tools on Linux or macOS:

### 3. Navigate to the Extracted Directory

### 4. Install the Package

pip install job_scraper-0.1-py3-none-any.whl
 or 
pip install job_scraper-0.1.tar.gz

### 5.Verifying the Installation

pip show job_scraper

### 6.Usage

from Job_scrapper import start_scraping

start_scraping()

It will ask two inputs 
- 1.Search Key words - Max 25 char
- 2.Number of pages to scrap - Max 10 Pages

